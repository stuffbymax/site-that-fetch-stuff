import { useState, useEffect } from 'react';

function App() {
  const [photos, setPhotos] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function getData() {
      try {
        const response = await fetch(
          "https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?earth_date=2015-6-3&api_key=aep4fv0UGnpneqGhFu9hucnocx8IFm4SzaCd7n9z"
        );
        if (!response.ok) throw new Error('Network response was not ok');
        const json_data = await response.json();
        setPhotos(json_data.photos);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    }

    getData();
  }, []);

  return (
    <>
      <meta charSet="utf-8" />
      <title>Mars Photo Viewer</title>
      <div>
        <h1>Mars Rover Photo of the Day</h1>
      </div>
      <div id="photo">
        {loading && <p>Loading photos...</p>}
        {error && <p>Error: {error}</p>}
        {!loading && !error && photos.length === 0 && (
          <p>No photos available for this date.</p>
        )}
        {!loading && !error && photos.length > 0 && (
          <>
            <p>Number of photos on 2015-06-03: {photos.length}</p>
            <img
              src={photos[0].img_src}
              alt="Mars Rover Photo"
              style={{ maxWidth: '100%', height: 'auto' }}
            />
          </>
        )}
      </div>
    </>
  );
}

export default App;
