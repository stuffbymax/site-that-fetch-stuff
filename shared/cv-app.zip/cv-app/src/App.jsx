import React, { useState } from "react";
import { Document, Packer, Paragraph, TextRun } from "docx";
import { saveAs } from "file-saver";
export default function App() {

  const exportToWord = () => {
  const doc = new Document({
    sections: [
      {
        children: [
          new Paragraph({
            children: [new TextRun({ text: name, bold: true, size: 32 })],
          }),
          new Paragraph({ text: `${email} | ${phone}`, spacing: { after: 200 } }),
          about && new Paragraph({ text: "About Me", heading: "Heading2" }),
          about && new Paragraph({ text: about, spacing: { after: 300 } }),

          new Paragraph({ text: "Education", heading: "Heading2" }),
          ...education.map(
            (edu) =>
              new Paragraph({
                text: `${edu.degree}, ${edu.school} (${edu.studyDate})`,
                bullet: { level: 0 },
              })
          ),

          new Paragraph({ text: "Experience", heading: "Heading2" }),
          ...experience.flatMap((exp) => [
            new Paragraph({
              children: [
                new TextRun({ text: exp.title, bold: true }),
                new TextRun({ text: ` at ${exp.company}` }),
              ],
            }),
            new Paragraph({
              text: `${exp.workFrom} - ${exp.workUntil}`,
              italics: true,
              spacing: { after: 100 },
            }),
            new Paragraph({
              text: exp.responsibilities,
              bullet: { level: 0 },
              spacing: { after: 300 },
            }),
          ]),
        ].filter(Boolean),
      },
    ],
  });

  Packer.toBlob(doc).then((blob) => {
    saveAs(blob, `${name || "CV"}.docx`);
  });
};
  // General Info
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [about, setAbout] = useState("");

  // Education (array of objects)
  const [education, setEducation] = useState([
    { school: "", degree: "", studyDate: "" },
  ]);

  // Experience (array of objects)
  const [experience, setExperience] = useState([
    { company: "", title: "", responsibilities: "", workFrom: "", workUntil: "" },
  ]);

  // Auto-fill function
  const autoFill = () => {
    setName("Jane Doe");
    setEmail("jane.doe@example.com");
    setPhone("+1 555-123-4567");
    setAbout(
      "Passionate software engineer with 3+ years of experience in building web applications. Skilled in React, Node.js, and problem-solving."
    );

    setEducation([
      { school: "State University", degree: "BSc in Computer Science", studyDate: "2016 - 2020" },
      { school: "Tech Academy", degree: "Frontend Development Certificate", studyDate: "2021" },
    ]);

    setExperience([
      {
        company: "Tech Corp",
        title: "Software Engineer",
        responsibilities: "Developed web applications, collaborated with team members, optimized backend APIs.",
        workFrom: "Jan 2021",
        workUntil: "Present",
      },
      {
        company: "Web Solutions",
        title: "Intern",
        responsibilities: "Assisted in frontend development, wrote documentation, supported QA testing.",
        workFrom: "Jun 2020",
        workUntil: "Dec 2020",
      },
      {
        company: "google",
        title: "Intern",
        responsibilities: "Assisted in frontend development, wrote documentation, supported QA testing.",
        workFrom: "Jun 2019",
        workUntil: "April 2019",
      },
    ]);
  };

  // Add new education row
  const addEducation = () => {
    setEducation([...education, { school: "", degree: "", studyDate: "" }]);
  };

  // Delete education row
  const deleteEducation = (index) => {
    setEducation(education.filter((_, i) => i !== index));
  };

  // Add new experience row
  const addExperience = () => {
    setExperience([
      ...experience,
      { company: "", title: "", responsibilities: "", workFrom: "", workUntil: "" },
    ]);
  };

  // Delete experience row
  const deleteExperience = (index) => {
    setExperience(experience.filter((_, i) => i !== index));
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial", maxWidth: "700px", margin: "auto" }}>
      <h1>CV Builder</h1>

      <button onClick={autoFill} style={{ marginBottom: "20px" }}>
        Auto-Fill Example
      </button>

      <h2>General Info</h2>
      <input placeholder="Name" value={name} onChange={e => setName(e.target.value)} /><br />
      <input placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} /><br />
      <input placeholder="Phone" value={phone} onChange={e => setPhone(e.target.value)} /><br />

      <h2>About Me</h2>
      <textarea
        placeholder="Write a short summary about yourself"
        value={about}
        onChange={e => setAbout(e.target.value)}
        rows={4}
        style={{ width: "100%" }}
      /><br />

      <h2>Education</h2>
      {education.map((edu, index) => (
        <div key={index} style={{ marginBottom: "10px", borderBottom: "1px solid #ddd", paddingBottom: "10px" }}>
          <input
            placeholder="School"
            value={edu.school}
            onChange={e => {
              const newEdu = [...education];
              newEdu[index].school = e.target.value;
              setEducation(newEdu);
            }}
          /><br />
          <input
            placeholder="Degree"
            value={edu.degree}
            onChange={e => {
              const newEdu = [...education];
              newEdu[index].degree = e.target.value;
              setEducation(newEdu);
            }}
          /><br />
          <input
            placeholder="Date of Study"
            value={edu.studyDate}
            onChange={e => {
              const newEdu = [...education];
              newEdu[index].studyDate = e.target.value;
              setEducation(newEdu);
            }}
          /><br />
          <button onClick={() => deleteEducation(index)} style={{ color: "red" }}>
            ❌ Delete
          </button>
        </div>
      ))}
      <button onClick={addEducation}>+ Add Education</button>

      <h2>Experience</h2>
      {experience.map((exp, index) => (
        <div key={index} style={{ marginBottom: "10px", borderBottom: "1px solid #ddd", paddingBottom: "10px" }}>
          <input
            placeholder="Company"
            value={exp.company}
            onChange={e => {
              const newExp = [...experience];
              newExp[index].company = e.target.value;
              setExperience(newExp);
            }}
          /><br />
          <input
            placeholder="Job Title"
            value={exp.title}
            onChange={e => {
              const newExp = [...experience];
              newExp[index].title = e.target.value;
              setExperience(newExp);
            }}
          /><br />
          <textarea
            placeholder="Main Responsibilities"
            value={exp.responsibilities}
            onChange={e => {
              const newExp = [...experience];
              newExp[index].responsibilities = e.target.value;
              setExperience(newExp);
            }}
            rows={3}
            style={{ width: "100%", marginTop: "5px" }}
          /><br />
          <input
            placeholder="From (e.g., Jan 2020)"
            value={exp.workFrom}
            onChange={e => {
              const newExp = [...experience];
              newExp[index].workFrom = e.target.value;
              setExperience(newExp);
            }}
          /><br />
          <input
            placeholder="Until (e.g., Present)"
            value={exp.workUntil}
            onChange={e => {
              const newExp = [...experience];
              newExp[index].workUntil = e.target.value;
              setExperience(newExp);
            }}
          /><br />
          <button onClick={() => deleteExperience(index)} style={{ color: "red" }}>
            ❌ Delete
          </button>
        </div>
      ))}
      <button onClick={addExperience}>+ Add Experience</button>

      <h2>Live Preview</h2>
      <button onClick={exportToWord} style={{ marginLeft: "10px" }}>
      Export to Word
      </button>

      <div style={{ border: "1px solid gray", padding: "15px", borderRadius: "5px" }}>
        <h3>{name}</h3>
        <p>{email} | {phone}</p>
        {about && (
          <>
            <h4>About Me</h4>
            <p>{about}</p>
          </>
        )}

        <h4>Education</h4>
        {education.map((edu, i) => (
          <p key={i}>{edu.degree}, {edu.school} ({edu.studyDate})</p>
        ))}

        <h4>Experience</h4>
        {experience.map((exp, i) => (
          <div key={i} style={{ marginBottom: "10px" }}>
            <p>
              <strong>{exp.title}</strong> at {exp.company} <br />
              <em>{exp.workFrom} - {exp.workUntil}</em>
            </p>
            <p>{exp.responsibilities}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
