import { useState, useEffect } from 'react';
import './App.css';

function App() {
  
  const API_URL = "https://api.thecatapi.com/v1/";
  const API_KEY = "live_fCy0xiv0nQYf85XuPp5tTcI5LYMQnQOp2dQJWSs8WOawIcTYOG1A1DOH5pkGolLt"; 
  
  const [currentImage, setCurrentImage] = useState(null);
  const [votes, setVotes] = useState([]);
  const [view, setView] = useState("vote"); // 'vote' or 'history'

  // Fetch a new image to vote on
  const fetchImage = () => {
    fetch(`${API_URL}images/search`, {
      headers: { "x-api-key": API_KEY },
    })
      .then((res) => res.json())
      .then((data) => {
        setCurrentImage(data[0]);
      })
      .catch(console.error);
  };

  // Fetch vote history
  const fetchVotes = () => {
    fetch(`${API_URL}votes?limit=10&order=DESC`, {
      headers: { "x-api-key": API_KEY },
    })
      .then((res) => res.json())
      .then(setVotes)
      .catch(console.error);
  };

  // On initial load or when switching to vote view, get new image
  useEffect(() => {
    if (view === "vote") {
      fetchImage();
    } else if (view === "history") {
      fetchVotes();
    }
  }, [view]);

  // Send vote
  const vote = (value) => {
    if (!currentImage) return;

    fetch(`${API_URL}votes/`, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": API_KEY,
      },
      body: JSON.stringify({
        image_id: currentImage.id,
        value,
      }),
    })
      .then(() => fetchImage())
      .catch(console.error);
  };

  // State inside component
  const [photos, setPhotos] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

    // Fetch Mars photos on mount
  useEffect(() => {
    async function getData() {
      try {
        const response = await fetch(
          "https://api.nasa.gov/mars-photos/api/v1/rovers/curiosity/photos?earth_date=2015-6-3&api_key=aep4fv0UGnpneqGhFu9hucnocx8IFm4SzaCd7n9z"
        );
        if (!response.ok) throw new Error('Network response was not ok');
        const json_data = await response.json();
        setPhotos(json_data.photos);
      } catch (error) {
        setError(error.message);
      } finally {
        setLoading(false);
      }
    }

    getData();
  }, []);

  // Weather state
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState(null);
  const [weatherError, setWeatherError] = useState(null);

  // Fetch weather when button clicked
  async function getWeather() {
    if (!city) {
      alert('Please enter a city name');
      return;
    }

    const apiKey = 'caa3c5a3121630838545026f24db4c34'; // Replace with your OpenWeatherMap API key
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${apiKey}`;

    try {
      const res = await fetch(url);
      const data = await res.json();

      if (data.cod === 200) {
        setWeather(data);
        setWeatherError(null);
      } else {
        setWeather(null);
        setWeatherError('City not found. Try again.');
      }
    } catch (err) {
      setWeather(null);
      setWeatherError('Failed to fetch weather data.');
    }
    
  }
  
  const fetchPokemons = async () => {
    try {

    const response = await fetch('https://pokeapi.co/api/v2/pokemon?limit=151')
    const data = await response.json();
    setPokemons(data.results);
    } catch (error) {
       console.error('Failed to fetch Pokemons:', error);
    
}
  };

  useEffect(() => {
    fetchPokemons();
  }, []);
  return (
    <div className="app">
      <h1>Weather App</h1>
      <h4>Note: if the city name exists in multiple countries (e.g. Halifax), type it like Halifax,UK</h4>
      <input
        type="text"
        placeholder="Enter city name"
        value={city}
        onChange={(e) => setCity(e.target.value)}
      />
      <button onClick={getWeather}>Get Weather</button>

      <div id="result">
        {weather && (
          <>
            <h2>{weather.name}</h2>
            <p>{weather.weather[0].main} - {weather.weather[0].description}</p>
            <p>
              🌡️ Temp: {weather.main.temp}°C{' '}
              {weather.main.temp < 20 ? (
                <span className="coldContainer">
                  <span className="coldMessage">🥶 It's cold!</span>
                  {[...Array(5)].map((_, i) => (
                    <span
                      key={i}
                      className="particle coldParticle"
                      style={{
                        left: `${i * 15}px`,
                        animationDuration: `${2 + i}s`,
                        animationDelay: `${i * 0.5}s`,
                      }}
                    />
                  ))}
                </span>
              ) : (
                <span className="warmContainer">
                  <span className="warmMessage">🥵 It's warm!</span>
                  {[...Array(5)].map((_, i) => (
                    <span
                      key={i}
                      className="particle warmParticle"
                      style={{
                        left: `${i * 15}px`,
                        animationDuration: `${1.5 + i}s`,
                        animationDelay: `${i * 0.3}s`,
                      }}
                    />
                  ))}
                </span>
              )}
            </p>
            <p>💨 Wind: {weather.wind.speed} m/s</p>
          </>
        )}

        {weatherError && <p style={{ color: 'red' }}>{weatherError}</p>}
      </div>
      
      <h1>cat voter</h1>
      
          <div className="App">
      <header>
        <button onClick={() => setView("vote")}>Vote</button>
        <button onClick={() => setView("history")}>History</button>
      </header>

      {view === "vote" && currentImage && (
        <div id="vote-options">
          <img
            id="image-to-vote-on"
            src={currentImage.url}
            alt="Cat to vote on"
            width="300"
          />
          <div>
            <button onClick={() => vote(1)}>Upvote</button>
            <button onClick={() => vote(-1)}>Downvote</button>
          </div>
        </div>
      )}

      {view === "history" && (
        <div id="vote-results" style={{ display: "block" }}>
          <div id="grid" style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
            {votes.map((voteData) => (
              <div
                key={voteData.id}
                className={`col-lg ${voteData.value < 0 ? "red" : "green"}`}
                style={{ border: "1px solid #ccc", padding: "10px" }}
              >
                <img
                  src={voteData.image?.url}
                  alt="Voted cat"
                  width="150"
                  style={{ display: "block" }}
                />
                <p>Vote: {voteData.value}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>

      <div className="app">
        <h1>i was there when AWS went boom 20/10/2025</h1>
      </div>

      <div>
        <h1>doesnt work because of nasa funding 😭</h1>
        <h1>Mars Rover Photo of the Day</h1>
        <div id="photo">
          {loading && <p>Loading photos...</p>}
          {error && <p>Error: {error}</p>}
          {!loading && !error && photos.length === 0 && (
            <p>No photos available for this date.</p>
          )}
          {!loading && !error && photos.length > 0 && (
            <>
              <p>Number of photos on 2015-06-03: {photos.length}</p>
              <img
                src={photos[0].img_src}
                alt="Mars Rover"
                style={{ maxWidth: '100%', height: 'auto' }}
              />
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;
